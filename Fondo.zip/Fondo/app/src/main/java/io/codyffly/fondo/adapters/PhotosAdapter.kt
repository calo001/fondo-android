package io.codyffly.fondo.adapters

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.RecyclerView.ViewHolder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.bumptech.glide.RequestManager
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade
import com.bumptech.glide.request.RequestOptions
import io.codyffly.fondo.R
import io.codyffly.fondo.activities.PhotoDetailActivity
import io.codyffly.fondo.configs.Constants
import io.codyffly.fondo.models.Photo
import kotlinx.android.synthetic.main.item_loading.view.*
import kotlinx.android.synthetic.main.item_photo.view.*

class PhotosAdapter(val items: MutableList<Photo?>, val context: Context) :
    RecyclerView.Adapter<ViewHolder>() {

    var glide: RequestManager = Glide.with(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return when (viewType) {
            VIEW_TYPE_ITEM -> ItemViewHolder(
                LayoutInflater.from(context).inflate(
                    R.layout.item_photo, parent,false)
            )
            else -> LoadingViewHolder(
                LayoutInflater.from(context)
                    .inflate(R.layout.item_loading, parent, false))
        }
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int){
        when (holder) {
            is ItemViewHolder -> showItemPhoto(holder, position)
            is LoadingViewHolder -> showItemLoading(holder, position)
        }
    }

    override fun getItemCount(): Int{
        return items.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (items[position] == null) VIEW_TYPE_LOADING else VIEW_TYPE_ITEM
    }

    fun showItemLoading(holder: LoadingViewHolder, position: Int) {

    }

    fun showItemPhoto(holder: ItemViewHolder, position: Int) {
        /*val requestOptions = RequestOptions()
            .transforms(RoundedCorners(8))
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .placeholder(R.drawable.back_loading_photo)*/

        glide
            .load(items[position]?.urls?.small)
            //.apply(requestOptions)
            .transition(withCrossFade())
            .into(holder.photo)

        holder.autor.text = items[position]?.user?.name
        holder.photo.setOnClickListener {
            val intent = Intent(context, PhotoDetailActivity::class.java)
            intent.putExtra(Constants.EXTRA_URI_IMAGE_VIEW, items[position]?.urls?.regular)
            context.startActivity(intent)
        }
    }

    class ItemViewHolder(itemView: View) : ViewHolder (itemView) {
        val autor = itemView.txtAutor
        val photo = itemView.imgPhoto
    }

    class LoadingViewHolder(itemView: View) : ViewHolder (itemView) {
        val progress = itemView.progressBar
    }

    companion object {
        const val VIEW_TYPE_ITEM = 0
        const val VIEW_TYPE_LOADING = 1
    }
}