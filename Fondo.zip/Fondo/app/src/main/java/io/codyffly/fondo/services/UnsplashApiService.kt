package io.codyffly.fondo.services

import io.codyffly.fondo.configs.Constants
import io.codyffly.fondo.models.Photo
import io.codyffly.fondo.models.Result
import io.reactivex.Observable
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface UnsplashApiService {
    @GET("photos/")
    fun dailyPhotos(@Query("client_id") clientID: String,
                    @Query("page") page: Int,
                    @Query("per_page") perPage: Int,
                    @Query("order_by") orderBy: String): Observable<List<Photo>>

    @GET("search/photos")
    fun searchPhotos(@Query("client_id") clientID: String,
                     @Query("query") query: String,
                     @Query("page") page: Int,
                     @Query("per_page") perPage: Int): Observable<Result>

    /*
    * Companion object to create the UnsplashApiService
    * */
    companion object Factory {
        fun create(): UnsplashApiService {
            val retrofit = Retrofit.Builder()
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(Constants.API_UNSPLASH)
                .build()
            return retrofit.create(UnsplashApiService::class.java)
        }
    }
}