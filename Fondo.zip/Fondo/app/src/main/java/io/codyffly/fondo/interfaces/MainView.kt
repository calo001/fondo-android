package io.codyffly.fondo.interfaces

import io.codyffly.fondo.models.Photo

interface MainView {

}