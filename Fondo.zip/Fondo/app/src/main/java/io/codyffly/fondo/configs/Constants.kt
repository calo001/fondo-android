package io.codyffly.fondo.configs

object Constants {
    const val API_KEY_UNSPLASH = "51531311dfa090ab81321cd2655e73c59b3d952b5966ed42e861fa7d50da47e8"
    const val API_UNSPLASH = "https://api.unsplash.com/"

    const val EXTRA_URI_IMAGE_VIEW = "uri_image_view"
}