package io.codyffly.fondo.repository

import io.codyffly.fondo.configs.Constants
import io.codyffly.fondo.models.Photo
import io.codyffly.fondo.models.Result
import io.codyffly.fondo.services.UnsplashApiService
import io.reactivex.Observable

class UnsplashRepository(val apiService: UnsplashApiService) {
    fun getDailyPhotos(page: Int, perPage: Int = 12, orderBy: String = "latest"): Observable<List<Photo>> {
        return apiService.dailyPhotos(Constants.API_KEY_UNSPLASH, page, perPage, orderBy)
    }

    fun getQueryPhotos(query: String, page: Int, perPage: Int = 12): Observable<Result> {
        return apiService.searchPhotos(Constants.API_KEY_UNSPLASH, query, page, perPage)
    }
}