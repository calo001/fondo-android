package io.codyffly.fondo.repository

import io.codyffly.fondo.services.UnsplashApiService

object UnsplashRepositoryProvider {
    fun provideUnsplashRepository(): UnsplashRepository {
        return UnsplashRepository(UnsplashApiService.create())
    }
}