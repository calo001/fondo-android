package io.codyffly.fondo.models

data class Category (val icon: Int, val name: Int, val background: Int)