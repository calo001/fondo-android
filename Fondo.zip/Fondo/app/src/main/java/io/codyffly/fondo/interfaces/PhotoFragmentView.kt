package io.codyffly.fondo.interfaces

import io.codyffly.fondo.models.Photo

interface PhotoFragmentView {
    fun setupPhotosList()
    fun onPhotosListSuccess(items: List<Photo>)
    //fun onPhotosListSuccessEndless(items: List<Photo>)
    fun onPhotosListError(error: Throwable)
}