package io.codyffly.fondo.activities

import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.github.piasy.biv.indicator.progresspie.ProgressPieIndicator
import io.codyffly.fondo.R
import io.codyffly.fondo.configs.Constants
import io.codyffly.fondo.dialogs.MenuFragment
import kotlinx.android.synthetic.main.activity_photo_detail.*

class PhotoDetailActivity : AppCompatActivity() {

    var uriImageView: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo_detail)

        getExtraInfo()
        showImage()
    }

    private fun showImage() {
        bigImageView.setProgressIndicator(ProgressPieIndicator())
        bigImageView.showImage(Uri.parse(uriImageView))
    }

    private fun getExtraInfo() {
        uriImageView = intent?.extras?.getString(Constants.EXTRA_URI_IMAGE_VIEW)
    }

    fun showDetails(view: View) {
        val menuFragment = MenuFragment()
        menuFragment.show(supportFragmentManager, menuFragment.tag)
    }
}
