package io.codyffly.fondo.fragments

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast

import io.codyffly.fondo.R
import io.codyffly.fondo.adapters.PhotosAdapter
import io.codyffly.fondo.interfaces.PhotoFragmentView
import io.codyffly.fondo.models.Photo
import io.codyffly.fondo.repository.UnsplashRepository
import io.codyffly.fondo.repository.UnsplashRepositoryProvider
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_photos.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [PhotosFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [PhotosFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class PhotosFragment : Fragment(), PhotoFragmentView {
    private var listener: OnFragmentInteractionListener? = null
    var repository: UnsplashRepository = UnsplashRepositoryProvider.provideUnsplashRepository()
    var photos: MutableList<Photo?> = mutableListOf()
    var isLoading = false
    var page = 1

    @SuppressLint("CheckResult")
    override fun setupPhotosList() {
        repository.getDailyPhotos(page)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .subscribe (
                { onPhotosListSuccess(it) },
                { onPhotosListError(it) })
    }

    fun clearLoading() {
        isLoading = false
        if (photos.size > 0) {
            photos.removeAt(photos.size - 1)
        }
    }

    override fun onPhotosListSuccess(items: List<Photo>) {
        clearLoading()
        photos.addAll(items)
        rvTodayPhotos.adapter?.notifyDataSetChanged()
    }

    override fun onPhotosListError(error: Throwable) {
        clearLoading()
        Toast.makeText(this.context, "ERROR CUSTOM: " + error.localizedMessage, Toast.LENGTH_LONG).show()
    }

    private fun loadMore() {
        photos.add(null)
        rvTodayPhotos.adapter?.notifyItemInserted(photos.size - 1)
        setupPhotosList()
    }

    private fun initScrollListener() {
        rvTodayPhotos.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val layoutManager = recyclerView.layoutManager
                if (!isLoading) {
                    if (layoutManager is LinearLayoutManager &&
                        layoutManager.findLastCompletelyVisibleItemPosition() == (photos.size.minus(1))) {
                        page++
                        isLoading = true
                        loadMore()
                    }
                }
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {}
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_photos, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        rvTodayPhotos.layoutManager = LinearLayoutManager(activity)
        activity.let {
            rvTodayPhotos.adapter = PhotosAdapter(photos, it!!.application)
            initScrollListener()
            setupPhotosList()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment PhotosFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        //fun newInstance(param1: String, param2: String) =
        fun newInstance() =
            PhotosFragment().apply {
                //arguments = Bundle().apply {
                //    putString(ARG_PARAM1, param1)
                //    putString(ARG_PARAM2, param2)
                //}
            }
    }
}
