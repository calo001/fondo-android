package io.codyffly.fondo.fragments


import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast

import io.codyffly.fondo.R
import io.codyffly.fondo.adapters.PhotosAdapter
import io.codyffly.fondo.models.Photo
import io.codyffly.fondo.models.Result
import io.codyffly.fondo.repository.UnsplashRepository
import io.codyffly.fondo.repository.UnsplashRepositoryProvider
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_search.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class SearchFragment : Fragment() {
    var repository: UnsplashRepository = UnsplashRepositoryProvider.provideUnsplashRepository()
    var photos: MutableList<Photo?> = mutableListOf()
    var isLoading = false
    var query = "cat"
    var page = 1

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        rvSearchPhotos.layoutManager = LinearLayoutManager(activity)
        activity.let {
            rvSearchPhotos.adapter = PhotosAdapter(photos, activity!!.application)
            initScrollListener()
            setupPhotoList()
        }
    }

    @SuppressLint("CheckResult")
    private fun setupPhotoList() {
        if (!query.trim().isEmpty()) {
            repository.getQueryPhotos(query, page)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(
                    { onPhotoListSucces(it) },
                    { onPhotosListError(it) }
                )
        }
    }

    fun onPhotosListError(error: Throwable) {
        clearLoading()
        Toast.makeText(this.context, "ERROR CUSTOM: " + error.localizedMessage, Toast.LENGTH_LONG).show()
    }

    private fun onPhotoListSucces(result: Result) {
        clearLoading()
        photos.addAll(result.results)
        rvSearchPhotos.adapter?.notifyDataSetChanged()
    }

    fun updateQuerySearch(query: String) {
        clearList()
        setupPhotoList()
    }

    private fun clearLoading() {
        isLoading = false;
        if (photos.size > 0) {
            photos.removeAt(photos.size.minus(1))
        }
    }

    private fun clearList() {
        photos.clear()
        rvSearchPhotos.adapter?.notifyDataSetChanged()
    }

    private fun initScrollListener() {
        rvSearchPhotos.addOnScrollListener(object: RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val layoutManager = recyclerView.layoutManager
                if (!isLoading) {
                    if (layoutManager is LinearLayoutManager &&
                        layoutManager.findLastCompletelyVisibleItemPosition() == photos.size.minus(1)) {
                        page++
                        isLoading = true
                        loadMore()
                    }
                }
            }
        })
    }

    private fun loadMore() {
        photos.add(null)
        rvSearchPhotos.adapter?.notifyItemInserted(photos.size.minus(1))
        setupPhotoList()
    }

    companion object {
        @JvmStatic
        fun newInstance() = SearchFragment()
    }
}
